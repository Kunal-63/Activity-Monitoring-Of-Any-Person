from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import instaloader
import requests
import re
import spacy
from testing import classify_text

# import instagramy
import locationtagger
app = FastAPI()
ig = instaloader.Instaloader()

# Pydantic model for incoming login requests
class LoginRequest(BaseModel):
    username: str
    password: str



# Initialize dictionaries to store the frequencies
number_frequency = {}
hashtag_frequency = {}
location_frequency = {}
profile_pic_url = ""
offensive_bio = {}

@app.get("/number-frequency")
async def get_data():
    return number_frequency

@app.get("/hashtag-frequency")
async def get_data():
    keys_to_delete = []

    for i, j in hashtag_frequency.items():
        predict = classify_text(i[1::])
        if predict != 1:
            keys_to_delete.append(i)

    for key in keys_to_delete:
        del hashtag_frequency[key]

    return hashtag_frequency

@app.get("/location-frequency")
async def get_data():
    return location_frequency

@app.get("/profile-picture")
async def get_data():
    return {"profile_path" : profile_pic_url}

@app.get("/offensive-bio")
async def get_data():
    return offensive_bio

# Login endpoint
@app.post("/login")
async def login(request: LoginRequest):
    global number_frequency
    global hashtag_frequency
    global location_frequency

    username = request.username
    password = request.password

    try:
        ig.login(username, password)
    except Exception as e:
        print(f"Login failed: {str(e)}")
        raise HTTPException(status_code=401, detail="Login failed")
    
    global profile
    profile = instaloader.Profile.from_username(ig.context, username)
    global profile_pic_url
    profile_pic_url = profile.get_profile_pic_url()

    response = requests.get(profile_pic_url)

    if response.status_code == 200:
        with open(f"{profile.username}.jpg", 'wb') as file:
            file.write(response.content)
        print(f"Profile picture downloaded for {profile.username}")
    else:
        print("Failed to download the profile picture.")

    # Extract phone numbers
    number_frequency = extract_number_frequencies(profile)

    # Extract hashtag frequencies
    hashtag_frequency = extract_hashtag_frequencies(profile)

    # Extract location frequencies
    location_frequency = extract_loaction_frequency()

    return {"message": "Login successful"}

#============================================================================================================================

def extract_number_frequencies(profile):
    frequency_of_numbers = {}
    numbers_list = []
    
    bio = profile.biography
    matches = re.findall(r'\b(?:\+91|0)?[789]\d{9}\b', bio.strip())
    if matches:
        numbers_list.extend(matches)

    for post in profile.get_posts():
        caption = post.caption
        matches = re.findall(r'\b(?:\+91|0)?[789]\d{9}\b', caption.strip())
        numbers_list.extend(matches)

        for comment in post.get_comments():
            matches = re.findall(r'\b(?:\+91|0)?[789]\d{9}\b', comment.text.strip())
            numbers_list.extend(matches)

    for post in profile.get_tagged_posts():
        caption = post.caption
        matches = re.findall(r'\b(?:\+91|0)?[789]\d{9}\b', caption.strip())
        numbers_list.extend(matches)

        for comment in post.get_comments():
            matches = re.findall(r'\b(?:\+91|0)?[789]\d{9}\b', comment.text.strip())
            numbers_list.extend(matches)

    for number in numbers_list:
        count = numbers_list.count(number)
        frequency_of_numbers[number] = count

    return frequency_of_numbers

def extract_hashtag_frequencies(profile):
    frequency_of_hashtags = {}
    hashtags_list = []

    bio = profile.biography
    matches = re.findall(r'#\w+', bio.strip())
    if matches:
        hashtags_list.extend(matches)

    for post in profile.get_posts():
        caption = post.caption
        matches = re.findall(r'#\w+', caption.strip())
        hashtags_list.extend(matches)

        for comment in post.get_comments():
            matches = re.findall(r'#\w+', comment.text.strip())
            hashtags_list.extend(matches)

    for post in profile.get_tagged_posts():
        caption = post.caption
        matches = re.findall(r'#\w+', caption.strip())
        hashtags_list.extend(matches)

        for comment in post.get_comments():
            matches = re.findall(r'#\w+', comment.text.strip())
            hashtags_list.extend(matches)

    for hashtag in hashtags_list:
        count = hashtags_list.count(hashtag)
        frequency_of_hashtags[hashtag] = count

    return frequency_of_hashtags

def extract_loaction_frequency():
    location_list = []
    nlp = spacy.load("en_core_web_sm")

    def extract_locations_from_text(user_input):
        doc = nlp(user_input)
        locations = [ent.text for ent in doc.ents if ent.label_ == "GPE"]
        return locations

    for post in profile.get_posts():
        caption = post.caption
        matches = extract_locations_from_text(caption.strip())
        location_list.extend(matches)

        for comment in post.get_comments():
            matches = extract_locations_from_text(comment.text.strip())
            location_list.extend(matches)
    
    for post in profile.get_tagged_posts():
        caption = post.caption
        matches = extract_locations_from_text(caption.strip())
        location_list.extend(matches)

        for comment in post.get_comments():
            matches = extract_locations_from_text(comment.text.strip())
            location_list.extend(matches)
    
    for location in location_list:
        count = location_list.count(location)
        location_frequency[location] = count
    
    return location_frequency

def offensive_bio():
    bio = profile.biography
    for words in bio.split():
        predict = classify_text(words)
        if predict == 1:
            offensive_bio[profile.username] = bio
            break

    return offensive_bio

if __name__ == '__main__':
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=5200)